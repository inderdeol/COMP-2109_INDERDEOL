<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'cms' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '/84H.)+C})0jPe7<mb;0IPt4K#>.OCr%hD|J8afYFd[ZVTUvIV<tT]?^lcTh>>]-' );
define( 'SECURE_AUTH_KEY',  'm2m*wCo8)<X@h1hq3giz,_ X4x+]YX#gFV7!gKr]]:9!Tr+fDXt>LHk50oiQ,]t+' );
define( 'LOGGED_IN_KEY',    '_tatkZ#HPE4fb3z=(!F$r0F]az}eA~^5g#bvRQn}NT_zd|6|~oK4M:0K.s|Yo8Mr' );
define( 'NONCE_KEY',        '(.JSBeB/gZ/-S{NsSQw5tVA+H^_7|>h[)u.{r=f+*K#UjzO ;8`c.[&Z9+u]X4XC' );
define( 'AUTH_SALT',        'DJCyQd_Ezt*w+{PB%?{Hav5nq5WJjfCfB)$s_(eGlctoPZ-XHO1#[eZ%`;R$M4ad' );
define( 'SECURE_AUTH_SALT', 'bk&<eH&U*kQk] T)K4Dd07q`AYCG-1JHO*0!$Slf0O%87!DP]kBQlKgdnu7_5g=+' );
define( 'LOGGED_IN_SALT',   'M bZ!N/>^-l0+iR<P 6-{~.aW&cC<_onW|&ay.(-AsvH._v~I:Y2H|ZTgT~j}i4$' );
define( 'NONCE_SALT',       '.dDZzDEQ$I7|+l|#chn+#*p.y_`OV)Oy=uXjpZWfHF4StOw^+~gH<$${h_a14`py' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
